下边我们展示如果对“苹果”进行从提取标题，到最终分析的全过程。

举例：

根据qwen和yicai两个文件夹下，各自有一个environment.yml，分别创建conda环境：qwen 和 yicai, 一个作为千问大模型的本地服务器，另一个跑专门处理数据。

在qwen环境下，运行
python qwen_server.py
从而启动本地服务器。

在yicai环境下，做如下步骤，我们以苹果举例。

如何统计苹果的所有标题？
这个请自行实现。或者请直接使用我整理好的yicai_苹果.xlsx放到本目录下。


```bash
python sentiment_qwen.py --infile yicai_苹果.xlsx --title-col title
```
得到`output_苹果.xlsx`

```bash
python build_quarter.py --infile output_苹果.xlsx
python append_sentiment_sheets.py -i output_苹果.xlsx
```
得到`quarter_苹果.xlsx`,更新`output_苹果.xlsx`


在output_苹果.xlsx中，将有4个sheets。分别是全部标题，正面，中性，负面。

后续可自行根据关键字“股”，“市值”，“跌”等，自行对负面新闻进行二次筛选，并可人工筛选一部分。
最终区别出股市相关的负面新闻，和股市无关的负面新闻。
