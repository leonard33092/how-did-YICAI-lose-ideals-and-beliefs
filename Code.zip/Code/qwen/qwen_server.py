from fastapi import FastAPI
from pydantic import BaseModel
import uvicorn, torch
from transformers import AutoModelForCausalLM, AutoTokenizer

# 选兼容 transformers==4.33.3 的模型（推荐 Qwen1.5-7B-Chat；显存不够就改成 Qwen1.5-4B-Chat / Qwen2.5-3B-Instruct）
MODEL_ID = "Qwen/Qwen1.5-7B-Chat"

tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, trust_remote_code=True, use_fast=False)
model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    trust_remote_code=True,
    device_map="auto",
    torch_dtype=torch.float16,   # 用 FP16
)

app = FastAPI()
class ChatReq(BaseModel):
    system: str = ""
    user: str

@app.post("/chat")
def chat(req: ChatReq):
    messages = []
    if req.system:
        messages.append({"role":"system","content":req.system})
    messages.append({"role":"user","content":req.user})
    text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    inputs = tokenizer([text], return_tensors="pt").to(model.device)
    gen = model.generate(
        **inputs,
        max_new_tokens=256,
        do_sample=False,
        temperature=0.0
    )
    out = tokenizer.decode(gen[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)
    return {"text": out}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
