import argparse, os, re, json
from datetime import datetime, timedelta
import pandas as pd

VALID = {"正面", "中性", "负面"}

def parse_rel_time(txt: str, now: datetime) -> datetime | None:
    """解析中文相对时间与常见格式到 datetime"""
    s = (txt or "").strip()
    if not s:
        return None

    # X小时前 / X小時前
    m = re.match(r"^\s*(\d+)\s*小?时\s*前\s*$", s)
    if m:
        return now - timedelta(hours=int(m.group(1)))

    # 昨天 HH:MM / 前天 HH:MM
    m = re.match(r"^\s*(昨|前)天\s+(\d{1,2}):(\d{2})\s*$", s)
    if m:
        day = -1 if m.group(1) == "昨" else -2
        hh, mm = int(m.group(2)), int(m.group(3))
        base = (now + timedelta(days=day)).replace(hour=hh, minute=mm, second=0, microsecond=0)
        return base

    # MM-DD HH:MM（默认今年）
    m = re.match(r"^\s*(\d{2})-(\d{2})\s+(\d{1,2}):(\d{2})\s*$", s)
    if m:
        y = now.year
        mo, da, hh, mm = map(int, m.groups())
        try:
            return datetime(y, mo, da, hh, mm)
        except Exception:
            return None

    # 完整日期
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d", "%Y/%m/%d %H:%M", "%Y/%m/%d"):
        try:
            return datetime.strptime(s, fmt)
        except Exception:
            pass
    return None

def ensure_time(df: pd.DataFrame, time_col: str = "time") -> pd.Series:
    """把 df[time_col] 统一成 datetime（新列 time_norm）"""
    now = datetime.now()
    col = time_col if time_col in df.columns else None
    if not col:
        raise KeyError("未找到时间列 'time'。")

    if pd.api.types.is_datetime64_any_dtype(df[col]):
        return pd.to_datetime(df[col], errors="coerce")

    out = []
    for x in df[col].astype(str).tolist():
        dt = parse_rel_time(x, now)
        if dt is None:
            try:
                dt = pd.to_datetime(x, errors="coerce")
            except Exception:
                dt = pd.NaT
        out.append(dt)
    return pd.to_datetime(out, errors="coerce")

def parse_qwen_sentiment_cell(cell: str) -> tuple[str, float]:
    """
    从 qwen_sentiment 单元格解析出 (label, confidence)
    支持已是 dict/JSON 字符串/或空
    """
    if isinstance(cell, dict):
        d = cell
    else:
        s = (cell or "").strip()
        # 如果是纯 JSON 字符串
        if s.startswith("{") and s.endswith("}"):
            try:
                d = json.loads(s)
            except Exception:
                d = {}
        else:
            d = {}
    label = str(d.get("label", "")).strip()
    conf = d.get("confidence", None)
    try:
        conf = float(conf) if conf is not None else None
    except Exception:
        conf = None
    return label, conf if conf is not None else 1.0

def label_conf_to_score01(label: str, conf: float) -> float:
    """
    将(标签, 置信度)映射到 0~1：
      正面→1，中性→0.5，负面→0，然后乘以置信度做缩放：score = base*conf + (1-conf)*0.5
      这样 conf 越低，趋向中性（0.5）
    """
    base = 1.0 if label == "正面" else (0.0 if label == "负面" else 0.5)
    # 让低置信度回到中性
    score = base*conf + 0.5*(1.0-conf)
    return float(max(0.0, min(1.0, score)))

def main():
    ap = argparse.ArgumentParser(description="从 output_ABC.xlsx 生成 quarter_ABC.xlsx（季度情感占比与得分）")
    ap.add_argument("--infile", "-i", required=True, help="输入文件，如 output_华为.xlsx")
    ap.add_argument("--outdir", default=".", help="输出目录（默认当前目录）")
    ap.add_argument("--sheet", default=None, help="指定数据表（默认首个工作表）")
    args = ap.parse_args()

    base = os.path.basename(args.infile)
    m = re.match(r"output_(.+?)\.xlsx$", base, flags=re.IGNORECASE)
    if not m:
        raise ValueError("输入文件名需形如 output_ABC.xlsx")
    tag = m.group(1)
    outfile = os.path.join(args.outdir, f"quarter_{tag}.xlsx")

    # 读取
    df = pd.read_excel(args.infile, sheet_name=args.sheet) if args.sheet else pd.read_excel(args.infile)
    if "qwen_sentiment" not in df.columns:
        raise KeyError("未找到列 'qwen_sentiment'。请确保先用 Qwen 标注脚本生成该列。")
    if "time" not in df.columns and "time_norm" not in df.columns:
        raise KeyError("未找到时间列 'time' 或 'time_norm'。")

    # 时间
    tser = pd.to_datetime(df["time_norm"], errors="coerce") if "time_norm" in df.columns else ensure_time(df, "time")
    df = df.assign(time_norm=tser).dropna(subset=["time_norm"]).copy()
    if df.empty:
        raise ValueError("时间字段无法解析，结果为空。")

    # 情感解析
    labels, confs = [], []
    for cell in df["qwen_sentiment"].tolist():
        lbl, cf = parse_qwen_sentiment_cell(cell)
        labels.append(lbl if lbl in VALID else "中性")
        confs.append(cf if cf is not None else 1.0)

    df["ts_label"] = labels
    df["ts_confidence"] = confs
    df["ts_score01"] = [label_conf_to_score01(l, c) for l, c in zip(labels, confs)]

    # 季度
    df["quarter"] = df["time_norm"].dt.to_period("Q").astype(str)

    # 聚合
    grp = df.groupby("quarter", as_index=False).agg(
        total=("ts_label", "count"),
        pos_cnt=("ts_label", lambda s: (s == "正面").sum()),
        neu_cnt=("ts_label", lambda s: (s == "中性").sum()),
        neg_cnt=("ts_label", lambda s: (s == "负面").sum()),
        score01=("ts_score01", "mean"),
        start=("time_norm", "min"),
        end=("time_norm", "max"),
    )
    for c in ["pos_cnt", "neu_cnt", "neg_cnt"]:
        grp[c.replace("_cnt", "_pct")] = (grp[c] / grp["total"]).round(4)
    grp["score01"] = grp["score01"].round(4)
    grp = grp.sort_values("quarter").reset_index(drop=True)

    # 写出
    with pd.ExcelWriter(outfile, engine="openpyxl") as w:
        grp.to_excel(w, sheet_name="quarter_share", index=False)

    print(f"✅ 已生成：{outfile}")
    try:
        print(grp.tail(8).to_string(index=False))
    except Exception:
        pass

if __name__ == "__main__":
    main()
