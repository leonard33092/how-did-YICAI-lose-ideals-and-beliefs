import argparse, json, os
import pandas as pd

VALID = {"正面", "中性", "负面"}

def extract_label(cell):
    """从 qwen_sentiment 单元格提取 label；容错 JSON/字典/空值。"""
    if isinstance(cell, dict):
        d = cell
    else:
        s = (str(cell) or "").strip()
        if s.startswith("{") and s.endswith("}"):
            try:
                d = json.loads(s)
            except Exception:
                d = {}
        else:
            d = {}
    label = str(d.get("label", "")).strip()
    return label if label in VALID else None

def main():
    ap = argparse.ArgumentParser(
        description="把现有 xlsx 的第1页保留为全部新闻，追加第2/3/4页为 正面/中性/负面"
    )
    ap.add_argument("-i", "--infile", required=True, help="输入文件，如 output_苹果.xlsx")
    ap.add_argument("--sheet", default=None, help="全部新闻所在工作表名（不填则默认第一个）")
    ap.add_argument("--outfile", default=None, help="另存为；不填则覆盖原文件（推荐以保证顺序）")
    ap.add_argument("--col", default="qwen_sentiment", help="情感JSON列名，默认 qwen_sentiment")
    args = ap.parse_args()

    # 读入“全部新闻”sheet
    if args.sheet:
        df_all = pd.read_excel(args.infile, sheet_name=args.sheet)
        first_sheet_name = args.sheet
    else:
        xls = pd.ExcelFile(args.infile)
        first_sheet_name = xls.sheet_names[0]
        df_all = pd.read_excel(xls, sheet_name=first_sheet_name)

    if args.col not in df_all.columns:
        raise KeyError(f"未找到列 {args.col}，请确认文件含有 Qwen 返回的情感JSON列。")

    # 解析标签（若已有 ts_label 就直接用）
    if "ts_label" in df_all.columns:
        labels = df_all["ts_label"].astype(str).str.strip()
    else:
        labels = df_all[args.col].apply(extract_label).fillna("中性")

    df_all = df_all.copy()
    df_all["__label"] = labels

    df_pos = df_all[df_all["__label"] == "正面"].drop(columns="__label")
    df_neu = df_all[df_all["__label"] == "中性"].drop(columns="__label")
    df_neg = df_all[df_all["__label"] == "负面"].drop(columns="__label")

    # 输出顺序：1) 原始全部新闻（原名保留） 2) 正面 3) 中性 4) 负面
    outfile = args.outfile or args.infile
    with pd.ExcelWriter(outfile, engine="openpyxl", mode="w") as w:
        df_all.drop(columns="__label").to_excel(w, sheet_name=first_sheet_name, index=False)
        df_pos.to_excel(w, sheet_name="正面", index=False)
        df_neu.to_excel(w, sheet_name="中性", index=False)
        df_neg.to_excel(w, sheet_name="负面", index=False)

    print(f"✅ 已写入：{outfile}")
    print(f" - 第1页：{first_sheet_name}（全部新闻，{len(df_all)} 行）")
    print(f" - 第2页：正面（{len(df_pos)} 行）")
    print(f" - 第3页：中性（{len(df_neu)} 行）")
    print(f" - 第4页：负面（{len(df_neg)} 行）")

if __name__ == "__main__":
    main()
