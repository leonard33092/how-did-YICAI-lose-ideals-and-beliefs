import argparse
import requests
import pandas as pd
import os

def call_qwen(title, company):
    url = "http://localhost:8000/chat"
    headers = {"Content-Type": "application/json"}
    payload = {
        "system": "只判断标题对<目标公司>的态度（正面/中性/负面），忽略大盘/其它主体。输出JSON：{\"label\":\"正面|中性|负面\",\"confidence\":0-1,\"evidence\":[\"关键词\"]}",
        "user": f"目标公司：{company}\n标题：{title}"
    }
    try:
        r = requests.post(url, headers=headers, json=payload, timeout=60)
        r.raise_for_status()
        data = r.json()
        return data.get("text", "")
    except Exception as e:
        return str(e)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--infile", required=True, help="输入 Excel 文件 yicai_xxx.xlsx")
    parser.add_argument("--title-col", default="title", help="标题所在的列名")
    args = parser.parse_args()

    infile = args.infile
    company = os.path.splitext(os.path.basename(infile))[0].split("_")[1]
    df = pd.read_excel(infile)

    results = []
    for t in df[args.title_col].fillna("").tolist():
        res = call_qwen(t, company)
        results.append(res)

    df["qwen_sentiment"] = results
    outfile = f"output_{company}.xlsx"
    df.to_excel(outfile, index=False)
    print(f"✅ 已保存 {outfile}")
